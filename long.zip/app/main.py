﻿# app/main.py
import os
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import JSONResponse
from app.gpt_extractor import extract_offer_from_pdf_bytes, ExtractionError

app = FastAPI(title="GPT-5 Offer Extractor", version="0.2.0")

@app.get("/healthz")
def healthz():
    return {"ok": True, "model": os.getenv("GPT_MODEL", "gpt-5")}

@app.post("/extract/pdf")
async def extract_pdf(file: UploadFile = File(...)):
    if not file.filename.lower().endswith(".pdf"):
        raise HTTPException(status_code=415, detail="PDF required")
    data = await file.read()
    try:
        payload = extract_offer_from_pdf_bytes(data, document_id=file.filename or "uploaded.pdf")
        return JSONResponse(payload)
    except ExtractionError as e:
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Unexpected error: {e}")
